#include "BSTNode.hpp"

BSTNode::BSTNode(): left(NULL), right(NULL){}